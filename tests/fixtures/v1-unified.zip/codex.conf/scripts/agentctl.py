#!/usr/bin/env python3
"""Portable, dependency-free deployment of reviewed Codex configuration.

No model calls, no git writes, no network fetch, and no auth/session synchronization.
Python 3.11+. Every destructive replacement has a checked local backup.
"""
from __future__ import annotations

import argparse
import contextlib
import copy
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shutil
import stat
import subprocess
import sys
import tempfile
import uuid
from typing import Any, Iterator

try:
    import tomllib
except ModuleNotFoundError:
    raise SystemExit("Python 3.11 이상이 필요합니다. PYTHON_BIN으로 설치된 Python 경로를 지정하세요.")

ROOT = Path(__file__).resolve().parents[1]
NAME = re.compile(r"^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$")
ROLES = {"architect", "scout", "backend", "frontend", "executor", "critic", "security", "test"}
COMMON_KEYS = {"model", "model_reasoning_effort", "approvals_reviewer", "service_tier",
               "approval_policy", "sandbox_mode", "agents"}
FORBIDDEN_LOCAL = COMMON_KEYS | {"profile", "profiles", "developer_instructions", "base_instructions",
                               "experimental_instructions_file", "model_instructions_file"}
BASE_AGENT_KEYS = {"enabled", "max_concurrent_threads_per_session", "default_subagent_model",
                   "default_subagent_reasoning_effort", "interrupt_message"}
ROLE_KEYS = {"name", "description", "model", "model_reasoning_effort", "sandbox_mode",
             "developer_instructions", "agents"}
EFFORTS = {"minimal", "low", "medium", "high", "xhigh", "max"}


class Error(Exception):
    """An actionable, non-destructive validation failure."""


def require(condition: bool, message: str) -> None:
    if not condition:
        raise Error(message)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def exists(path: Path) -> bool:
    return path.exists() or path.is_symlink()


def toml(path: Path) -> dict[str, Any]:
    try:
        return tomllib.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, tomllib.TOMLDecodeError) as e:
        # Do not echo user-supplied TOML values, which can contain credentials.
        raise Error(f"TOML 읽기/문법 오류: {path} ({type(e).__name__})") from e


def encode(value: Any) -> str:
    """Serialize supported TOML values (including inline tables/arrays) without dependencies."""
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, str):
        return json.dumps(value, ensure_ascii=False)
    if isinstance(value, (int, float)):
        return repr(value)
    if isinstance(value, (dt.datetime, dt.date, dt.time)):
        return value.isoformat()
    if isinstance(value, list):
        return "[" + ", ".join(encode(v) for v in value) + "]"
    if isinstance(value, dict):
        return "{ " + ", ".join(f"{encode(str(k))} = {encode(v)}" for k, v in value.items()) + " }"
    raise Error(f"지원하지 않는 TOML 값 형식: {type(value).__name__}")


def dumps(data: dict[str, Any]) -> str:
    lines: list[str] = []
    def section(obj: dict[str, Any], parts: list[str]) -> None:
        scalars = [(k, v) for k, v in obj.items() if not isinstance(v, dict)]
        tables = [(k, v) for k, v in obj.items() if isinstance(v, dict)]
        if parts:
            lines.append("[" + ".".join(encode(p) for p in parts) + "]")
        lines.extend(f"{encode(str(k))} = {encode(v)}" for k, v in scalars)
        lines.append("")
        for k, v in tables:
            section(v, parts + [str(k)])
    section(data, [])
    result = "\n".join(lines).strip() + "\n"
    require(tomllib.loads(result) == data, "TOML 직렬화 round-trip 검증 실패")
    return result


def merge(left: dict[str, Any], right: dict[str, Any]) -> dict[str, Any]:
    result = copy.deepcopy(left)
    for key, val in right.items():
        if key in result and isinstance(result[key], dict) and isinstance(val, dict):
            result[key] = merge(result[key], val)
        else:
            # Arrays are replaced, never concatenated or duplicated.
            result[key] = copy.deepcopy(val)
    return result


def content_tree_hash(path: Path) -> str:
    require(path.is_dir() and not path.is_symlink(), f"실제 스킬 디렉터리가 필요합니다: {path}")
    h = hashlib.sha256()
    for p in sorted(path.rglob("*")):
        require(not p.is_symlink(), f"원본/이전 스킬 내부 링크는 자동 처리하지 않습니다: {p}")
        if p.is_file():
            h.update(p.relative_to(path).as_posix().encode() + b"\0" + p.read_bytes() + b"\0")
    return h.hexdigest()


def fingerprint(path: Path) -> str:
    """Hash type, paths and content; never follow symlinks."""
    if not exists(path):
        return "absent"
    if path.is_symlink():
        return "link:" + sha(os.readlink(path).encode())
    if path.is_file():
        return "file:" + sha(path.read_bytes())
    require(path.is_dir(), f"특수 파일은 처리하지 않습니다: {path}")
    h = hashlib.sha256()
    for p in sorted(path.rglob("*")):
        rel = p.relative_to(path).as_posix()
        if p.is_symlink():
            token = "link:" + os.readlink(p)
        elif p.is_file():
            token = "file:" + sha(p.read_bytes())
        elif p.is_dir():
            token = "dir"
        else:
            raise Error(f"특수 파일은 처리하지 않습니다: {p}")
        h.update(rel.encode() + b"\0" + token.encode() + b"\0")
    return "dir:" + h.hexdigest()


def remove_node(path: Path) -> None:
    if path.is_symlink() or path.is_file():
        path.unlink()
    elif path.is_dir():
        shutil.rmtree(path)
    elif exists(path):
        raise Error(f"특수 파일을 삭제하지 않습니다: {path}")


def copy_node(source: Path, target: Path) -> None:
    require(not exists(target), f"복사 대상이 이미 존재합니다: {target}")
    target.parent.mkdir(parents=True, exist_ok=True)
    if source.is_symlink():
        os.symlink(os.readlink(source), target, target_is_directory=source.is_dir())
    elif source.is_dir():
        shutil.copytree(source, target, symlinks=True)
    elif source.is_file():
        shutil.copy2(source, target)
    else:
        raise Error(f"복사할 수 없는 파일 형식: {source}")


def write(path: Path, text: str, private: bool = False) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")
    path.chmod(0o600 if private else 0o644)


def atomic_json(path: Path, data: Any) -> None:
    tmp = path.with_name(path.name + ".tmp-" + uuid.uuid4().hex)
    try:
        with open(tmp, "x", encoding="utf-8") as f:
            if os.name != "nt":
                os.fchmod(f.fileno(), 0o600)
            json.dump(data, f, ensure_ascii=False, indent=2)
            f.write("\n")
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    finally:
        if exists(tmp):
            tmp.unlink()


def load_json(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as e:
        raise Error(f"상태 JSON 읽기 실패: {path}") from e


def check_yaml(path: Path, skill: str) -> None:
    """Validate this package's deliberately small, documented YAML subset."""
    top = None
    values: dict[str, dict[str, Any]] = {}
    for raw in path.read_text(encoding="utf-8").splitlines():
        if not raw.strip() or raw.lstrip().startswith("#"):
            continue
        if re.fullmatch(r"(interface|policy):", raw):
            top = raw[:-1]
            require(top not in values, f"중복 YAML 섹션: {path}")
            values[top] = {}
            continue
        m = re.fullmatch(r"  ([a-z_]+): (.+)", raw)
        require(top is not None and m is not None, f"지원하지 않는 YAML 구조: {path}")
        key, val = m.groups()
        require(key not in values[top], f"중복 YAML 키: {path}")
        if top == "policy":
            require(key == "allow_implicit_invocation" and val in {"true", "false"}, f"잘못된 스킬 정책: {path}")
            values[top][key] = val == "true"
        else:
            try:
                parsed = json.loads(val)
            except ValueError as e:
                raise Error(f"YAML 문자열은 JSON 호환 큰따옴표 형식이어야 합니다: {path}") from e
            require(isinstance(parsed, str) and parsed, f"빈 스킬 메타데이터: {path}")
            values[top][key] = parsed
    interface = values.get("interface", {})
    require(set(interface) == {"display_name", "short_description", "default_prompt"}, f"스킬 UI 메타데이터 누락/알 수 없는 키: {path}")
    require("$" + skill in interface["default_prompt"], f"스킬 호출 이름 불일치: {path}")
    require("allow_implicit_invocation" in values.get("policy", {}), f"명시적 스킬 호출 정책 필요: {path}")


def skill_frontmatter(path: Path, expected: str | None = None) -> dict[str, str]:
    text = path.read_text(encoding="utf-8")
    parts = text.split("---", 2)
    require(len(parts) == 3 and not parts[0].strip(), f"SKILL.md frontmatter 오류: {path}")
    meta: dict[str, str] = {}
    for line in parts[1].strip().splitlines():
        k, sep, v = line.partition(":")
        require(bool(sep) and k in {"name", "description"} and k not in meta, f"스킬 메타데이터 키 오류: {path}")
        meta[k] = v.strip().strip('"').strip("'")
    require(set(meta) == {"name", "description"} and all(meta.values()), f"스킬 이름/설명 필요: {path}")
    if expected is not None:
        require(meta["name"] == expected, f"스킬 폴더/이름 불일치: {path}")
    return meta


def verify(root: Path = ROOT, check_lock: bool = True) -> dict[str, Any]:
    for rel in ("manifest.toml", "config.toml", "AGENTS.md", "skills.lock.json", "agents", "skills", "policy", "config", "profiles", "docs/source-manifest.json"):
        require(not (root / rel).is_symlink(), f"배포 원본의 링크는 허용하지 않습니다: {rel}")
    manifest = toml(root / "manifest.toml")
    require(manifest.get("format_version") == 1, "지원하지 않는 manifest 형식")
    names = manifest.get("skills")
    require(isinstance(names, list) and len(names) == len(set(names)) and all(isinstance(n, str) and NAME.fullmatch(n) for n in names), "스킬 manifest의 중복/잘못된 이름")
    require(set(p.name for p in (root / "skills").iterdir()) == set(names), "스킬 디렉터리와 manifest가 다릅니다")
    base = toml(root / "config.toml")
    require(set(base) == COMMON_KEYS, "공통 config 키 오류: 기기별 값은 machine.toml, 공통 새 키는 검증 계약도 함께 갱신하세요")
    require(set(base["agents"]) == BASE_AGENT_KEYS, "공통 agents 키 오류(max_depth 등 옛 키는 이식하지 않음)")
    require(base["model_reasoning_effort"] in EFFORTS and isinstance(base["model"], str), "공통 모델/추론 오류")
    require(base["agents"]["enabled"] is True and base["agents"]["max_concurrent_threads_per_session"] == 3, "conf 동시성/활성 정책 불일치")
    require(base["approval_policy"] == "on-request" and base["sandbox_mode"] == "workspace-write", "공통 안전 기본값 변경 시 검증 계약도 명시적으로 검토하세요")
    require(base["approvals_reviewer"] in {"user", "auto_review"}, "승인 검토자 값 오류")
    require({p.stem for p in (root / "agents").glob("*.toml")} == ROLES, "에이전트 집합 불일치(test 유지, tester 미설치)")
    for p in (root / "agents").iterdir():
        require(p.suffix == ".toml", f"예상하지 않은 에이전트 원본: {p.name}")
        d = toml(p)
        require(not (set(d) - ROLE_KEYS), f"에이전트의 미지원 키: {p.name}")
        require(d.get("name") == p.stem and d.get("description") and d.get("developer_instructions"), f"에이전트 필수 필드 오류: {p.name}")
        require(d.get("model_reasoning_effort") in EFFORTS, f"에이전트 추론 값 오류: {p.name}")
        require(d.get("agents") == {"enabled": False}, f"하위 재위임 차단 누락: {p.name}")
        if p.stem in {"architect", "scout", "critic", "security"}:
            require(d.get("sandbox_mode") == "read-only", f"검토 역할의 읽기 전용 설정 누락: {p.name}")
    for p in (root / "config/os").glob("*.toml"):
        require(not (set(toml(p)) & FORBIDDEN_LOCAL), f"OS 레이어에서 공통 정책 변경 금지: {p.name}")
    for p in (root / "profiles").glob("*.toml"):
        require(p.stem.startswith("conf-") and NAME.fullmatch(p.stem), "관리 프로필은 conf- 접두사를 사용하세요")
        d = toml(p)
        require(set(d) <= {"model", "model_reasoning_effort"}, "선택 프로필에는 모델·추론 차이만 허용")
        require(d.get("model_reasoning_effort") in EFFORTS, "프로필 추론 오류")
    lock = load_json(root / "skills.lock.json")
    require(set(lock.get("skills", {})) == set(names), "skills.lock.json과 manifest의 스킬 집합이 다릅니다")
    for n in names:
        p = root / "skills" / n
        skill_frontmatter(p / "SKILL.md", n)
        check_yaml(p / "agents/openai.yaml", n)
        if check_lock:
            require(content_tree_hash(p) == lock["skills"][n]["managed_tree_sha256"], f"검토 후 lock-skills가 필요한 스킬: {n}")
    for folder in [root / "agents", root / "skills", root / "policy", root / "config", root / "profiles"]:
        for p in folder.rglob("*"):
            require(not p.is_symlink(), f"배포 원본의 심볼릭 링크는 허용하지 않습니다: {p}")
            require(p.name not in {"auth.json", "machine.toml", ".env", ".system"}, f"배포 원본에 로컬/인증 데이터가 있습니다: {p}")
    text = (root / "AGENTS.md").read_text(encoding="utf-8")
    require("/Users/orot" not in text and "codex.conf/state" not in text, "전역 지침에 기기 고정 경로가 남았습니다")
    return manifest


def payload_hash(root: Path = ROOT) -> str:
    selected = [root / p for p in ("config.toml", "AGENTS.md", "manifest.toml", "skills.lock.json")]
    for folder in ("agents", "policy", "skills", "config", "profiles"):
        selected += [p for p in (root / folder).rglob("*") if p.is_file()]
    h = hashlib.sha256()
    for p in sorted(selected):
        h.update(p.relative_to(root).as_posix().encode() + b"\0" + p.read_bytes() + b"\0")
    return h.hexdigest()


def source_revision() -> str:
    try:
        result = subprocess.run(["git", "-C", str(ROOT), "rev-parse", "HEAD"], capture_output=True, text=True, timeout=3)
        if result.returncode:
            return "archive (no Git commit)"
        dirty = subprocess.run(["git", "-C", str(ROOT), "status", "--porcelain"], capture_output=True, text=True, timeout=3)
        return result.stdout.strip() + (" + working-tree changes" if dirty.stdout else "")
    except (OSError, subprocess.TimeoutExpired):
        return "archive (no Git commit)"


class Paths:
    def __init__(self, args: argparse.Namespace):
        self.home = Path.home().resolve()
        code_raw = Path(os.path.expanduser(args.codex_home or os.environ.get("CODEX_HOME", str(self.home / ".codex")))).absolute()
        skills_raw = Path(os.path.expanduser(args.skills_home or str(self.home / ".agents/skills"))).absolute()
        require(not code_raw.is_symlink() and not skills_raw.is_symlink(), "CODEX_HOME/skills 루트 전체가 링크인 배치는 자동 변경하지 않습니다. 실제 디렉터리를 명시하세요")
        self.code = code_raw.resolve()
        self.skills = skills_raw.resolve()
        for p in (self.code, self.skills):
            require(p not in {Path(p.anchor), self.home} and "\n" not in str(p) and "\r" not in str(p), f"안전하지 않은 대상 루트: {p}")
            require(not (p == ROOT or p in ROOT.parents or ROOT in p.parents), "원본 저장소와 설치 경로는 겹칠 수 없습니다")
        require(self.code != self.skills and self.skills not in self.code.parents, "Codex 홈/스킬 루트 경계가 겹칩니다")
        self.manager = self.code / ".codex-conf"
        self.state_file = self.manager / "state.json"
        self.machine = self.manager / "machine.toml"
        self.pending = self.manager / "pending.json"
        self.work_state = self.code / "work-state"
        require(not self.manager.is_symlink(), "관리 상태 디렉터리가 링크입니다")
        if self.manager.exists() and hasattr(os, "getuid"):
            st = self.manager.stat()
            require(st.st_uid == os.getuid() and not st.st_mode & 0o022, "관리 상태 디렉터리의 소유권/쓰기 권한을 확인하세요")
        raw_os = args.os or ("mac" if sys.platform == "darwin" else "windows" if os.name == "nt" else "linux")
        self.os = "linux" if raw_os == "ubuntu" else raw_os

    def target_ok(self, p: Path) -> None:
        require(p.is_absolute(), "상태에 상대 대상 경로가 있습니다")
        fixed = {self.code / "config.toml", self.code / "AGENTS.md", self.code / "agents"}
        allowed = p in fixed
        if p.parent == self.code and re.fullmatch(r"conf-[a-z0-9-]+\.config\.toml", p.name):
            allowed = True
        if p.parent in {self.skills, self.code / "skills"} and NAME.fullmatch(p.name):
            allowed = True
        require(allowed, f"허용되지 않은 관리 대상: {p}")
        boundary = self.skills if p.parent == self.skills else self.code
        cur = p.parent
        while cur != boundary:
            require(not cur.is_symlink(), f"대상 상위 디렉터리 링크를 따라 쓰지 않습니다: {cur}")
            require(cur != cur.parent, "대상 루트 검사 실패")
            cur = cur.parent

    def state(self) -> dict[str, Any]:
        require(not self.pending.exists(), "미완료 설치가 있습니다. 다른 agentctl이 실행 중인지 확인한 뒤 recover를 실행하세요")
        if not self.state_file.exists():
            return {"format_version": 1, "targets": {}, "history": [], "payload_sha256": None}
        require(not self.state_file.is_symlink(), "상태 파일 링크를 허용하지 않습니다")
        state = load_json(self.state_file)
        require(state.get("format_version") == 1, "상태 버전 오류")
        require(state.get("codex_home") == str(self.code) and state.get("skills_home") == str(self.skills), "이전 설치와 홈/스킬 경로가 다릅니다. 이전 경로로 제거한 뒤 다시 설치하세요")
        for p, item in state["targets"].items():
            self.target_ok(Path(p))
            self.backup(item["baseline"])
            self.backup(item["after"])
        return state

    def backup(self, rel: str | None) -> Path | None:
        if rel is None:
            return None
        p = Path(rel)
        require(not p.is_absolute() and ".." not in p.parts and p.parts and p.parts[0] == "transactions", "안전하지 않은 백업 경로")
        result = self.manager / p
        # The final node may intentionally be an original symlink; ancestors may not.
        cur = result.parent
        while cur != self.manager:
            require(not cur.is_symlink(), "백업 상위 경로가 링크입니다")
            cur = cur.parent
        return result


@contextlib.contextmanager
def locked(paths: Paths) -> Iterator[None]:
    paths.code.mkdir(parents=True, exist_ok=True)
    paths.manager.mkdir(mode=0o700, exist_ok=True)
    for rel in ("transactions", "state.json", "pending.json", "machine.toml"):
        require(not (paths.manager / rel).is_symlink(), f"관리 상태 내부 링크를 허용하지 않습니다: {rel}")
    lock = paths.manager / "install.lock"
    try:
        with open(lock, "x", encoding="utf-8") as f:
            f.write(f"pid={os.getpid()}\nhost={platform.node()}\n")
            os.chmod(lock, 0o600)
    except FileExistsError as e:
        raise Error(f"다른 설치/미완료 작업의 잠금이 있습니다: {lock}. 프로세스 종료 확인 후에만 잠금 파일을 제거하세요") from e
    try:
        yield
    finally:
        lock.unlink(missing_ok=True)


def local_data(data: dict[str, Any]) -> dict[str, Any]:
    result = {k: copy.deepcopy(v) for k, v in data.items() if k not in COMMON_KEYS}
    require(not (set(result) & FORBIDDEN_LOCAL), "기존 설정의 profile/지침 override를 먼저 검토하세요. 자동으로 공통 정책을 우회하지 않습니다")
    features = result.get("features")
    if isinstance(features, dict):
        features.pop("multi_agent", None)  # Replaced by the conf agents.enabled contract.
        if not features:
            result.pop("features")
    return result


def effective_local(paths: Paths, state: dict[str, Any]) -> dict[str, Any]:
    current = toml(paths.code / "config.toml") if (paths.code / "config.toml").exists() else {}
    found = local_data(current)
    if exists(paths.machine):
        require(not paths.machine.is_symlink(), "machine.toml은 일반 파일이어야 합니다")
        machine = toml(paths.machine)
        require(not (set(machine) & FORBIDDEN_LOCAL), "machine.toml에서 모델/추론/agents/승인/샌드박스 등 공통 정책을 변경할 수 없습니다")
        if state.get("payload_sha256"):
            # Explicit local edits win. Otherwise capture app-written trust/UI changes.
            return machine if sha(paths.machine.read_bytes()) != state.get("machine_sha256") else found
        return merge(found, machine)
    return found


def check_drift(paths: Paths, state: dict[str, Any], allow_runtime_local: bool = False) -> list[str]:
    problems: list[str] = []
    for target, item in state["targets"].items():
        p = Path(target)
        if fingerprint(p) == item["expected"]:
            continue
        if allow_runtime_local and p == paths.code / "config.toml" and p.is_file() and not p.is_symlink():
            previous = paths.backup(item["after"])
            if previous and previous.is_file():
                old, now = toml(previous), toml(p)
                if {k: old.get(k) for k in COMMON_KEYS} == {k: now.get(k) for k in COMMON_KEYS}:
                    local_data(now)
                    continue
        problems.append(str(p))
    return problems


def duplicate_skills(paths: Paths, names: set[str], desired: dict[Path, Path | None]) -> list[str]:
    errors: list[str] = []
    roots = [paths.skills]
    if paths.code / "skills" != paths.skills:
        roots.append(paths.code / "skills")
    for root in roots:
        if not root.exists():
            continue
        require(not root.is_symlink(), f"스킬 루트 전체 링크는 먼저 기존 설치 도구로 복원하세요: {root}")
        for child in root.iterdir():
            if child.name.startswith(".") or child in desired:
                continue
            file = child / "SKILL.md"
            if file.is_file():
                try:
                    name = skill_frontmatter(file)["name"]
                except Error:
                    continue
                if name in names:
                    errors.append(str(child))
    return errors


def prepare(paths: Paths, state: dict[str, Any], stage: Path, manifest: dict[str, Any]) -> tuple[dict[Path, Path | None], dict[str, Any], list[str], set[str]]:
    require(not (paths.code / "AGENTS.override.md").exists(), "전역 AGENTS.override.md가 공통 지침을 가립니다. 내용을 검토해 옮긴 후 설치하세요(자동 삭제 안 함)")
    drift = check_drift(paths, state, allow_runtime_local=True)
    require(not drift, "설치본이 직접 수정되어 덮어쓰지 않습니다: " + ", ".join(drift))
    local = effective_local(paths, state)
    base = toml(ROOT / "config.toml")
    config = merge(merge(base, toml(ROOT / f"config/os/{paths.os}.toml")), local)
    payload = payload_hash()
    notes: list[str] = []
    desired: dict[Path, Path | None] = {}
    def file(target: Path, rel: str, text: str, private: bool = False) -> None:
        source = stage / rel
        write(source, text, private)
        desired[target] = source
    header = f"# Managed codex.conf snapshot: {payload}\n# Edit common source or .codex-conf/machine.toml, then agentctl sync.\n"
    file(paths.code / "config.toml", "config.toml", header + dumps(config), True)
    for p in sorted((ROOT / "profiles").glob("*.toml")):
        file(paths.code / (p.stem + ".config.toml"), p.stem + ".config.toml", header + dumps(merge(config, toml(p))), True)
    footer = ("\n## 설치 환경 (도구가 생성)\n\n"
              f"- 공통 패키지 SHA256: `{payload}`\n"
              f"- 실제 Codex 홈: `{paths.code.as_posix()}`\n"
              f"- 로컬 작업 기록: `{paths.work_state.as_posix()}/<workspace-key>/<task-id>.md`\n"
              "- 이 파일은 설치본이다. 원본 변경 후 agentctl sync로 적용한다. 기록 디렉터리 권한을 자동 확대하지 않는다.\n")
    file(paths.code / "AGENTS.md", "AGENTS.md", (ROOT / "AGENTS.md").read_text(encoding="utf-8") + footer)
    agents = stage / "agents"
    old_agents = paths.code / "agents"
    if old_agents.exists():
        require(old_agents.is_dir(), "agents 경로가 디렉터리가 아닙니다")
        # Detach legacy whole-directory symlink without changing its target repo.
        shutil.copytree(old_agents.resolve(), agents, symlinks=True)
    else:
        require(not old_agents.is_symlink(), "기존 agents 링크가 끊어졌습니다. 원본 복구 후 설치하세요")
        agents.mkdir()
    provenance = load_json(ROOT / "docs/source-manifest.json")
    old_tester = agents / "tester.toml"
    if old_tester.exists():
        require(old_tester.is_file() and sha(old_tester.read_bytes()) == provenance["legacy_tester_sha256"], "알 수 없는 tester 역할이 있습니다. test와의 관계를 검토한 뒤 별도 보관하세요")
        remove_node(old_tester)
        notes.append("기존 codex.file tester는 백업에 보존하고 현재 test로 통일")
    common = (ROOT / "policy/subagent-common.md").read_text(encoding="utf-8").strip()
    for p in sorted((ROOT / "agents").glob("*.toml")):
        d = toml(p)
        d["developer_instructions"] = d["developer_instructions"].strip() + "\n\n" + common + "\n"
        out = agents / p.name
        if exists(out):
            remove_node(out)
        write(out, dumps(d))
    # Name is the actual Codex role ID, not merely the filename.
    seen: set[str] = set()
    for p in sorted(agents.glob("*.toml")):
        name = toml(p).get("name", p.stem)
        require(name not in seen, f"중복 에이전트 name: {name}")
        seen.add(name)
    desired[old_agents] = agents
    for name in manifest["skills"]:
        source = stage / "skills" / name
        shutil.copytree(ROOT / "skills" / name, source)
        desired[paths.skills / name] = source
        legacy = paths.code / "skills" / name
        if paths.skills != paths.code / "skills" and exists(legacy):
            require(legacy.is_dir(), f"이전 스킬이 디렉터리가 아닙니다: {legacy}")
            candidate = legacy.resolve()
            require(content_tree_hash(candidate) == provenance["legacy_skills"][name], f"알 수 없거나 수정된 이전 스킬이 있습니다: {legacy}. 별도 보관 후 다시 실행하세요")
            desired[legacy] = None
            notes.append(f"기존 경로의 {name}을 백업하고 새 사용자 스킬 경로로 통합")
        # Keep a migrated legacy slot absent on every subsequent sync.
        if paths.skills != paths.code / "skills" and str(legacy) in state["targets"]:
            desired[legacy] = None
    errors = duplicate_skills(paths, set(manifest["skills"]), desired)
    require(not errors, "동일 name의 다른 사용자 스킬이 있습니다: " + ", ".join(errors))
    # A removed managed skill/profile restores its ORIGINAL pre-install item.
    retire: set[str] = set()
    for target, item in state["targets"].items():
        p = Path(target)
        if p not in desired:
            baseline = paths.backup(item["baseline"])
            require((fingerprint(baseline) if baseline else "absent") == item["baseline_hash"], f"최초 백업 무결성 오류: {p}")
            desired[p] = restoration_source(paths, p, item["baseline"], item.get("baseline_resolved"), item.get("baseline_resolved_hash"))
            retire.add(target)
            notes.append(f"manifest에서 제외된 관리 대상의 최초 상태 복원: {p.name}")
    for p in desired:
        paths.target_ok(p)
    return desired, local, notes, retire


def cli_check(stage: Path, expected_version: str = "") -> tuple[bool | None, str]:
    binary = shutil.which("codex")
    if not binary:
        return None, "Codex 실행 파일 없음: 실제 CLI 설정 로딩·모델 사용 가능 여부는 미검증"
    env = dict(os.environ, CODEX_HOME=str(stage))
    try:
        version = subprocess.run([binary, "--version"], capture_output=True, text=True, timeout=15, env=env)
        label = version.stdout.strip()
        if version.returncode:
            return False, "codex --version 실패"
        if expected_version and label != expected_version:
            return False, "Codex 버전이 manifest.expected_codex_version과 다릅니다"
        # Parser/config-only command: never invoke exec/chat or make a model request.
        with tempfile.TemporaryDirectory(prefix="codex-conf-probe-cwd-") as cwd:
            result = subprocess.run([binary, "-c", "check_for_update_on_startup=false", "features", "list"],
                                    cwd=cwd, env=env, capture_output=True, text=True, timeout=20)
        if result.returncode:
            return False, f"CLI 설정 로딩 실패(exit {result.returncode}). max 등 버전 호환성을 확인하세요. 설정을 자동 변경하지 않았습니다"
        return True, f"CLI 설정 로딩 성공: {label} (모델 호출·권한 집행·계정 지원 검증은 아님)"
    except (OSError, subprocess.TimeoutExpired) as e:
        return False, f"CLI 검사 실행 실패: {type(e).__name__}"


def save_machine(paths: Paths, data: dict[str, Any]) -> str:
    content = "# Machine-local only. Not Git. Common model/agent policy is not overridden here.\n" + dumps(data)
    tmp = paths.manager / ("machine.tmp-" + uuid.uuid4().hex)
    write(tmp, content, True)
    os.replace(tmp, paths.machine)
    return sha(paths.machine.read_bytes())


def swap(paths: Paths, destination: Path, source: Path | None) -> None:
    """Stage beside the destination, swap via rename, never write through old links."""
    paths.target_ok(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    nonce = uuid.uuid4().hex
    incoming = destination.with_name(".codex-conf-incoming-" + nonce)
    displaced = destination.with_name(".codex-conf-displaced-" + nonce)
    if source is not None:
        copy_node(source, incoming)
    had_old = exists(destination)
    try:
        if had_old:
            os.replace(destination, displaced)
        if source is not None:
            os.replace(incoming, destination)
    except BaseException:
        if exists(destination):
            remove_node(destination)
        if exists(displaced):
            os.replace(displaced, destination)
        raise
    finally:
        if exists(incoming):
            remove_node(incoming)
    if exists(displaced):
        remove_node(displaced)


def restoration_source(paths: Paths, target: Path, backup: str | None,
                       resolved: str | None = None, resolved_hash: str | None = None) -> Path | None:
    original = paths.backup(backup)
    if original is None or not original.is_symlink() or resolved is None:
        return original
    snapshot = paths.backup(resolved)
    require(snapshot is not None and fingerprint(snapshot) == resolved_hash, "링크 원본 콘텐츠 백업 무결성 오류")
    raw = Path(os.readlink(original))
    current = raw if raw.is_absolute() else target.parent / raw
    try:
        if current.exists() and fingerprint(current.resolve(strict=True)) == resolved_hash:
            return original
    except (OSError, RuntimeError):
        pass
    # A moved/deleted/edited old repo must not turn a restore into a dangling link
    # or overwrite that repo's new content. Restore the saved bytes locally.
    return snapshot


def restore_entries(paths: Paths, entries: list[dict[str, Any]]) -> None:
    for item in reversed(entries):
        before = paths.backup(item["before"])
        if before:
            require(fingerprint(before) == item["before_hash"], "원본 백업이 변경되어 복구를 중단합니다")
        source = restoration_source(paths, Path(item["target"]), item["before"],
                                    item.get("before_resolved"), item.get("before_resolved_hash"))
        swap(paths, Path(item["target"]), source)


def transact(paths: Paths, state: dict[str, Any], desired: dict[Path, Path | None], *,
             local: dict[str, Any] | None, uninstall: bool = False, retire: set[str] | None = None) -> bool:
    changes = [(p, s) for p, s in desired.items() if fingerprint(p) != (fingerprint(s) if s else "absent")]
    if not changes:
        print("변경 없음: 설치된 내용이 같습니다.")
        return False
    txid = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ-") + uuid.uuid4().hex[:12]
    txdir = paths.manager / "transactions" / txid
    txdir.mkdir(parents=True, mode=0o700)
    entries: list[dict[str, Any]] = []
    for i, (p, source) in enumerate(changes):
        before = txdir / "before" / str(i)
        after = txdir / "after" / str(i)
        bh = fingerprint(p)
        resolved_copy = txdir / "resolved-before" / str(i)
        if exists(p):
            copy_node(p, before)
            if p.is_symlink():
                require(p.exists(), f"끊어진 기존 링크는 백업할 수 없습니다: {p}")
                copy_node(p.resolve(strict=True), resolved_copy)
        if source:
            copy_node(source, after)
        entries.append({"target": str(p), "before": str(before.relative_to(paths.manager)) if exists(before) else None,
                        "before_hash": bh,
                        "before_resolved": str(resolved_copy.relative_to(paths.manager)) if exists(resolved_copy) else None,
                        "before_resolved_hash": fingerprint(resolved_copy) if exists(resolved_copy) else None,
                        "after": str(after.relative_to(paths.manager)) if source else None,
                        "after_hash": fingerprint(after)})
    record = {"format_version": 1, "id": txid, "previous_state": state, "entries": entries, "kind": "uninstall" if uninstall else "install"}
    atomic_json(txdir / "manifest.json", record)
    atomic_json(paths.pending, {"transaction": str((txdir / "manifest.json").relative_to(paths.manager)), "mode": "apply"})
    attempted: list[dict[str, Any]] = []
    try:
        for item in entries:
            require(fingerprint(Path(item["target"])) == item["before_hash"], "설치 도중 대상이 바뀌었습니다. Codex/다른 설치 도구를 종료하세요")
            attempted.append(item)
            swap(paths, Path(item["target"]), paths.backup(item["after"]))
        new = copy.deepcopy(state)
        new.update(codex_home=str(paths.code), skills_home=str(paths.skills), os=paths.os)
        if uninstall:
            new["targets"] = {}
            new["payload_sha256"] = None
        else:
            for item in entries:
                previous = new["targets"].get(item["target"])
                new["targets"][item["target"]] = {
                    "expected": item["after_hash"],
                    "baseline": previous["baseline"] if previous else item["before"],
                    "baseline_hash": previous["baseline_hash"] if previous else item["before_hash"],
                    "baseline_resolved": previous.get("baseline_resolved") if previous else item.get("before_resolved"),
                    "baseline_resolved_hash": previous.get("baseline_resolved_hash") if previous else item.get("before_resolved_hash"),
                    "after": item["after"],
                }
            for target in retire or set():
                new["targets"].pop(target, None)
            new["payload_sha256"] = payload_hash()
            new["source_revision"] = source_revision()
            new["machine_sha256"] = save_machine(paths, local or {})
        new["history"] = state.get("history", []) + [str((txdir / "manifest.json").relative_to(paths.manager))]
        atomic_json(paths.state_file, new)
        paths.pending.unlink()
        print(f"{'제거/최초 상태 복원' if uninstall else '설치'} 완료: {len(entries)}개 대상, transaction={txid}")
        return True
    except BaseException:
        # Best effort; leave journal if restore itself fails.
        restore_entries(paths, attempted)
        atomic_json(paths.state_file, state_with_roots(paths, state))
        paths.pending.unlink(missing_ok=True)
        raise


def state_with_roots(paths: Paths, state: dict[str, Any]) -> dict[str, Any]:
    return dict(state, codex_home=str(paths.code), skills_home=str(paths.skills))


def deployment(args: argparse.Namespace, paths: Paths, manifest: dict[str, Any]) -> None:
    apply = args.sessions_stopped and not args.dry_run
    with (locked(paths) if apply else contextlib.nullcontext()):
        state = paths.state()
        with tempfile.TemporaryDirectory(prefix="codex-conf-render-") as tmp:
            stage = Path(tmp)
            desired, local, notes, retire = prepare(paths, state, stage, manifest)
            print(f"OS={paths.os} | Codex={paths.code} | skills={paths.skills}")
            print(f"payload SHA256: {payload_hash()}")
            wanted = toml(ROOT / "config.toml")
            prior = toml(paths.code / "config.toml") if (paths.code / "config.toml").exists() else {}
            print(f"main: {prior.get('model', '(default)')} / {prior.get('model_reasoning_effort', '(default)')} -> {wanted['model']} / {wanted['model_reasoning_effort']}")
            print("로컬 보존 키(값은 출력 안 함): " + ", ".join(sorted(local)))
            changed = []
            for target, source in desired.items():
                status = "same" if fingerprint(target) == (fingerprint(source) if source else "absent") else "change"
                if status == "change":
                    changed.append(target)
                print(f"[{status}] {target}")
            for note in notes:
                print("[migration] " + note)
            if toml(ROOT / "config.toml")["model_reasoning_effort"] == "max":
                print("[compat] max는 첨부 원본 보존값입니다. 공개 참조는 xhigh까지 열거하므로 설치된 CLI의 지원 확인이 필요합니다.")
            if args.cli or (apply and not args.skip_cli_check):
                ok, message = cli_check(stage, manifest.get("expected_codex_version", ""))
                print("[cli] " + message)
                require(ok is not False, "CLI 검사 실패: 기존 설치본은 변경하지 않았습니다")
            if not apply:
                print("미리보기만 수행했습니다. Codex CLI/앱/IDE 작업을 모두 종료한 뒤 --sessions-stopped로 적용하세요.")
                return
            transact(paths, state, desired, local=local, retire=retire)
            print("새 세션에서 /skills와 역할 선택을 확인하세요. 인증·세션·.system은 변경하지 않았습니다.")


def rollback(paths: Paths, apply: bool) -> None:
    with (locked(paths) if apply else contextlib.nullcontext()):
        state = paths.state()
        require(state.get("history"), "되돌릴 배포가 없습니다")
        history_file = paths.backup(state["history"][-1])
        record = load_json(history_file)
        for item in record["entries"]:
            p = Path(item["target"])
            paths.target_ok(p)
            require(fingerprint(p) == item["after_hash"], f"설치 후 수정된 항목을 덮어쓰지 않습니다: {p}")
            before = paths.backup(item["before"])
            if before:
                require(fingerprint(before) == item["before_hash"], f"백업 무결성 오류: {p}")
            restoration_source(paths, p, item["before"], item.get("before_resolved"), item.get("before_resolved_hash"))
            print(f"[restore] {p}")
        if not apply:
            print("복구 미리보기. 모든 Codex 작업 종료 후 --sessions-stopped를 지정하세요.")
            return
        atomic_json(paths.pending, {"transaction": state["history"][-1], "mode": "rollback"})
        restore_entries(paths, record["entries"])
        previous = state_with_roots(paths, record["previous_state"])
        # Machine-local info is retained rather than discarded on rollback.
        atomic_json(paths.state_file, previous)
        paths.pending.unlink()
        print("직전 배포 복구 완료. machine.toml·작업 기록·인증은 보존했습니다.")


def uninstall(paths: Paths, apply: bool) -> None:
    with (locked(paths) if apply else contextlib.nullcontext()):
        state = paths.state()
        require(state["targets"], "현재 관리 중인 설치가 없습니다")
        require(not check_drift(paths, state), "수정된 설치본이 있어 제거를 중단합니다. 먼저 변경을 별도 보관하세요")
        desired = {}
        for target, item in state["targets"].items():
            p = Path(target)
            before = paths.backup(item["baseline"])
            require((fingerprint(before) if before else "absent") == item["baseline_hash"], f"최초 백업 무결성 오류: {p}")
            desired[p] = restoration_source(paths, p, item["baseline"], item.get("baseline_resolved"), item.get("baseline_resolved_hash"))
            print(f"[restore-original] {p}")
        if apply:
            transact(paths, state, desired, local=None, uninstall=True)
        else:
            print("제거 미리보기. 모든 Codex 작업 종료 후 --sessions-stopped를 지정하세요.")


def recover(paths: Paths, apply: bool) -> None:
    with (locked(paths) if apply else contextlib.nullcontext()):
        require(paths.pending.exists(), "미완료 transaction이 없습니다")
        pending = load_json(paths.pending)
        record = load_json(paths.backup(pending["transaction"]))
        for item in record["entries"]:
            p = Path(item["target"])
            paths.target_ok(p)
            # A kill between two renames can leave the destination absent.
            require(fingerprint(p) in {item["before_hash"], item["after_hash"], item.get("before_resolved_hash"), "absent"}, f"미완료 설치 후 수정된 파일이 있습니다. 자동 복구하지 않습니다: {p}")
            before = paths.backup(item["before"])
            require((fingerprint(before) if before else "absent") == item["before_hash"], f"복구 백업 무결성 오류: {p}")
            restoration_source(paths, p, item["before"], item.get("before_resolved"), item.get("before_resolved_hash"))
            print(f"[recover] {p}")
        if not apply:
            print("복구 미리보기. 설치 프로세스 종료·Codex 작업 종료 확인 후 --sessions-stopped를 지정하세요.")
            return
        restore_entries(paths, record["entries"])
        atomic_json(paths.state_file, state_with_roots(paths, record["previous_state"]))
        paths.pending.unlink()
        print("미완료 transaction 이전 상태로 복구했습니다. 임시 .codex-conf-displaced-* 파일은 자동 삭제하지 않습니다.")


def doctor(paths: Paths, args: argparse.Namespace, manifest: dict[str, Any]) -> int:
    state = paths.state()
    problems = check_drift(paths, state)
    print(f"source payload: {payload_hash()}")
    print(f"installed payload: {state.get('payload_sha256') or '(미설치)'}")
    if state.get("payload_sha256") != payload_hash():
        problems.append("source-install-differ")
        print("[outdated] 현재 원본과 설치본의 패키지 해시가 다릅니다(또는 미설치). plan으로 검토하세요")
    print(f"source Git: {source_revision()}")
    print(f"OS={paths.os} | CODEX_HOME={paths.code} | skills={paths.skills}")
    print(f"managed targets: {len(state['targets'])}")
    for p in problems:
        print("[drift] " + p)
    if (paths.code / "AGENTS.override.md").exists():
        problems.append("global-override")
        print("[warning] 전역 AGENTS.override.md가 배포 지침을 가립니다")
    if (paths.code / "config.toml").exists():
        d = toml(paths.code / "config.toml")
        print(f"main: {d.get('model')} / {d.get('model_reasoning_effort')}")
        print("로컬 예외 키(값은 출력 안 함): " + ", ".join(sorted(k for k in d if k not in COMMON_KEYS)))
        for p in sorted((paths.code / "agents").glob("*.toml")):
            role = toml(p)
            print(f"agent {role.get('name', p.stem)}: {role.get('model', 'inherit')} / {role.get('model_reasoning_effort', 'inherit')}")
        if str(paths.home) in d.get("projects", {}) or "/" in d.get("projects", {}):
            print("[warning] 기존 홈 전체/루트 trust가 보존되어 있습니다. 필요한 프로젝트만 신뢰하도록 기기에서 검토하세요")
    print("[scope] 전역 설치 파일 검사입니다. 프로젝트 설정·CLI 선택·앱 세션 선택·계정 모델 권한은 별도로 확인해야 합니다")
    if not manifest.get("expected_codex_version"):
        print("[version] Codex 버전 미고정. 확인한 공통 버전 문자열을 manifest에 기록할 수 있습니다")
    if args.cli:
        ok, message = cli_check(paths.code, manifest.get("expected_codex_version", ""))
        print("[cli] " + message)
        if ok is False:
            problems.append("cli")
    return 1 if problems else 0


def import_state(paths: Paths, source: str | None, apply: bool) -> None:
    require(bool(source), "import-state --source /이전/codex.conf/state 를 지정하세요")
    src = Path(source).expanduser().resolve()
    require(src.is_dir() and src != paths.work_state.resolve(), "다른 기존 state 디렉터리를 지정하세요")
    todo: list[tuple[Path, Path]] = []
    for p in sorted(src.rglob("*")):
        require(not p.is_symlink(), "작업 기록의 심볼릭 링크는 가져오지 않습니다")
        if not p.is_file() or p.suffix != ".md":
            continue
        target = paths.work_state / p.relative_to(src)
        require(not target.is_symlink(), "작업 기록 대상이 링크입니다")
        cur = target.parent
        while cur != paths.code:
            require(not cur.is_symlink(), "작업 기록 상위 경로가 링크입니다")
            cur = cur.parent
        if target.exists():
            require(target.read_bytes() == p.read_bytes(), f"서로 다른 기존 기록은 덮어쓰지 않습니다: {target}")
        else:
            todo.append((p, target))
    print(f"작업 기록 {len(todo)}개 신규 복사; 원본은 삭제하지 않습니다")
    if apply:
        with locked(paths):
            for p, target in todo:
                target.parent.mkdir(parents=True, exist_ok=True)
                # Exclusive creation prevents overwrites from a concurrent importer.
                with open(target, "xb") as f:
                    if os.name != "nt":
                        os.fchmod(f.fileno(), 0o600)
                    f.write(p.read_bytes())
    else:
        print("미리보기만 수행했습니다. --sessions-stopped로 복사하세요")


def stats(manifest: dict[str, Any]) -> None:
    global_text = (ROOT / "AGENTS.md").read_text(encoding="utf-8")
    common = (ROOT / "policy/subagent-common.md").read_text(encoding="utf-8")
    print(f"AGENTS 원본: {len(global_text)} characters / {len(global_text.encode())} UTF-8 bytes")
    for p in sorted((ROOT / "agents").glob("*.toml")):
        text = toml(p)["developer_instructions"] + common
        print(f"{p.stem}: generated instructions {len(text)} characters / {len(text.encode())} bytes")
    print(f"사용자 스킬 {len(manifest['skills'])}개. 메타데이터는 남으며 본문은 선택한 경우 로드합니다.")
    print("문자/바이트 수는 토큰 수·과금 절감률이 아닙니다. 실제 usage는 별도 세션 측정이 필요합니다.")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=["verify", "plan", "install", "sync", "doctor", "status", "rollback", "uninstall", "recover", "import-state", "stats", "lock-skills"])
    parser.add_argument("--os", choices=["mac", "linux", "ubuntu", "windows"])
    parser.add_argument("--codex-home")
    parser.add_argument("--skills-home")
    parser.add_argument("--sessions-stopped", action="store_true", help="모든 Codex CLI/앱/IDE 작업을 종료했음을 확인하고 로컬 변경 적용")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--cli", action="store_true", help="모델 호출 없는 codex features list 설정 로딩 검사")
    parser.add_argument("--skip-cli-check", action="store_true", help="명시적으로 실제 CLI 검사를 생략(권장하지 않음)")
    parser.add_argument("--source", help="import-state의 기존 state 디렉터리")
    args = parser.parse_args(argv)
    try:
        if args.command == "lock-skills":
            manifest = verify(check_lock=False)
            lock = load_json(ROOT / "skills.lock.json")
            for n in manifest["skills"]:
                lock["skills"][n]["managed_tree_sha256"] = content_tree_hash(ROOT / "skills" / n)
            atomic_json(ROOT / "skills.lock.json", lock)
            print("스킬 content hash 갱신. 자동 보안 승인/외부 최신 버전 조회는 아닙니다. Git diff로 검토하세요.")
            return 0
        # Restoration must not depend on a possibly broken/new source package.
        manifest = None if args.command in {"rollback", "uninstall", "recover", "import-state"} else verify()
        if args.command == "verify":
            print("원본 검증 통과: TOML·역할 계약·스킬 메타데이터·스킬 lock")
            if toml(ROOT / "config.toml")["model_reasoning_effort"] == "max":
                print("[compat] 원본의 max 보존. 공개 참조는 xhigh까지 열거: 실제 CLI 검사는 별도입니다")
            return 0
        if args.command == "stats":
            stats(manifest)
            return 0
        paths = Paths(args)
        apply = args.sessions_stopped and not args.dry_run
        if args.command in {"plan", "install", "sync"}:
            if args.command == "plan":
                args.dry_run = True
            deployment(args, paths, manifest)
        elif args.command in {"doctor", "status"}:
            return doctor(paths, args, manifest)
        elif args.command == "rollback":
            rollback(paths, apply)
        elif args.command == "uninstall":
            uninstall(paths, apply)
        elif args.command == "recover":
            recover(paths, apply)
        elif args.command == "import-state":
            import_state(paths, args.source, apply)
        return 0
    except (Error, OSError, ValueError) as e:
        print(f"agentctl: {e}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
