# 역할별 실제 설정

생성 기준: 배포 소스 TOML, 2026-09-16. 실행 시 `agentctl doctor`로 설치된 값을 다시 확인한다.

| 역할 | 모델 | 추론 | 기본 파일 접근 |
|---|---|---|---|
| main | `gpt-5.6-luna` | `max` | `workspace-write` |
| architect | `gpt-6-astra` | `medium` | `read-only` |
| security | `gpt-6-astra` | `low` | `read-only` |
| scout | `gpt-5.6-luna` | `low` | `read-only` |
| executor | `gpt-5.6-luna` | `low` | `inherit: workspace-write` |
| backend | `gpt-5.6-terra` | `low` | `inherit: workspace-write` |
| frontend | `gpt-5.6-terra` | `low` | `inherit: workspace-write` |
| test | `gpt-5.6-terra` | `low` | `inherit: workspace-write` |
| critic | `gpt-5.6-terra` | `medium` | `read-only` |

main은 하위 최대 3개, 기본 지침은 보통 1~2개다. 하위 8개 역할은 모두 agents.enabled=false로 생성한다. test의 테스트 파일 편집 제한 및 역할 범위는 지침과 소유권 계약이며 별도 파일별 OS 접근 제어를 구현한 것은 아니다.

선택 프로필 `conf-sol-high`만 main을 Sol/high로 바꾼다. 기본 모델이나 하위 역할은 자동으로 바꾸지 않는다. max 및 모델 접근 권한은 [호환성 문서](COMPATIBILITY.md)를 확인한다.
