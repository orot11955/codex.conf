# codex.conf 통합 판단 기록

작성일: 2026-09-16. 근거는 이번에 제공된 두 ZIP의 실제 내용이며, 과거 대화의 설정값을 원본 대신 사용하지 않았다. 사용자 기기·Gitea의 현재 파일을 조회하거나 변경한 것은 아니다.

## 우선순위

`codex.conf`의 실제 TOML과 역할 정책 → `codex.conf`의 최신 작업 방식 → 충돌하지 않는 `codex.file`의 장점 순서로 적용했다. 이름만 바꾸어 옛 설정을 복원하지 않았다.

| 항목 | 원본에서 발견한 상태 | 통합 결정 |
|---|---|---|
| 메인 모델 | conf 실제 Luna/max, README·전역 지침은 Sol/high | 실제 TOML의 Luna/max 유지. Sol/high는 명시적 대안으로만 제공 |
| architect / security | 현재 Astra medium / low | 유지. 옛 Sol로 바꾸지 않음 |
| scout / executor | 현재 Luna low / low | 유지 |
| backend / frontend / test | 현재 Terra low | 유지 |
| critic | 현재 Terra medium | 유지 |
| 동시 실행 | 현재 상한 3, 지침은 보통 1~2 | 유지. 옛 상한 2로 되돌리지 않음 |
| 재위임 | 현재 지침상 금지 | 공통 지침 + 각 하위 역할의 agents.enabled=false 추가 |
| interrupt_message | conf true, 옛 file false | 현재 true 유지 |
| 보안 검토 | 실제 신뢰 경계 변화에만 조건부 호출 | 유지. 모든 구현의 승인 단계로 확대하지 않음 |
| test / tester | 현재 test는 배정된 테스트 파일 작성 가능, 옛 tester는 실행 중심 | 현재 test 기준으로 역할명·스킬 계약 통일 |
| 스킬 | 옛 file의 사용자 7종과 별도 시스템 스킬 복사본 | 사용자 7종만 수정해 이식. .system 제외 |
| 인증 저장 방식 | 옛 mac 설정은 keyring 강제 | 기기별 기존 값 보존. 신규 OS 강제값 없음 |
| 신뢰 프로젝트 | conf에 사용자 홈·프로젝트 절대 경로 | 새 공통 배포에서 제외. 실제 기존 기기의 값은 로컬로 보존 |
| 장기 작업 기록 | conf/state 아래 실제 기록 40개, 지침에 특정 Mac 절대 경로 | 배포에서 제외. 로컬 work-state로 선택적 가져오기 |
| 설치 | conf는 직접 파일, 옛 file은 원본 실시간 링크 | 검증 후 일반 파일 복사 배포, 기존 링크는 안전하게 전환 |

원본의 정확한 파일 해시와 옛 스킬 식별용 fingerprint는 `source-manifest.json`에 있다. 이 파일은 출처 기록이지 디지털 서명이나 공급망 보안 보증이 아니다.

## 가져온 장점

옛 패키지의 백업·제거·복구 개념, 등록한 스킬만 관리하는 경계, 시스템 스킬과 사용자 상태를 건드리지 않는 원칙을 유지했다. 현재 패키지의 최소 위임, 파일 소유권, 짧은 결과 계약, 재개 기록, 조건부 보안 검토가 기본 작업 방식이다.

전역 지침에는 한국어 보고, 사실/추정과 실행/미실행 구분, 기존 사용자 변경 보존, 조사·리뷰 요청의 비수정 기본, 파괴적 외부 작업 승인, 비밀 보호, 검증을 약화해서 통과하지 않는 규칙, main만 Git 쓰기를 수행한다는 경계를 보완했다.

`approval_policy=on-request`, `sandbox_mode=workspace-write`는 옛 패키지에서 가져온 명시적인 안전 기본값이다. 현재 `approvals_reviewer=auto_review`, `service_tier=fast`는 유지했다. 자동 검토자는 사용자 업무 승인이나 운영 배포 승인을 대신하지 않는다.

## 스킬 이식 판단

`task-orchestration`, `codebase-exploration`, `change-design`, `implementation-loop`, `change-verification`, `change-review`, `security-review`를 통합했다. 옛 Sol 중심의 문구와 tester 호출, 상한 2 전제를 현재 main/test/상한 3에 맞추었다.

7개 스킬 모두 `allow_implicit_invocation=false`를 기본으로 둔다. 이는 스킬의 장문 Workflow가 모든 작은 작업에 자동으로 추가되는 것을 피하려는 선택이다. 일반적인 탐색·구현·검증과 조건부 security 호출은 전역 규칙으로 계속 수행한다. `$change-review`처럼 스킬을 명시하면 자세한 절차를 쓴다.

외부 스킬을 자동 다운로드하는 코드는 없다. 원본 ZIP 출처와 검토한 설치 내용의 SHA256을 고정하는 로컬 lock만 구현했다. 사용자가 별도로 설치한 archify, go-modern-guidelines 등은 이번 ZIP에서 확인되지 않았으므로 이름만 추정해 새 패키지에 넣지 않았다. 기존 다른 스킬은 설치 과정에서 보존한다.

## 배포 보완

관리 대상은 공통 config, 전역 AGENTS, 8개 역할을 포함한 agents 디렉터리, 등록한 사용자 스킬, 명시적 프로필이다. agents 디렉터리의 미등록 사용자 역할도 복사해 보존한다. 다만 디렉터리를 통째로 관리하므로 설치 후 해당 디렉터리의 직접 변경은 충돌로 탐지한다.

설치 전 원본과 대상 해시·TOML·역할명·스킬 metadata·lock을 검증한다. 잘못된 대상 경로, 전역 override, 알 수 없는 같은 이름 스킬, 수정된 옛 tester는 자동 병합하지 않는다. 기기별 TOML은 구조적으로 병합하고 공통 정책 override는 금지한다.

설치마다 교체 전후 백업과 transaction 기록을 남긴다. 기존 원본 링크에는 해석된 콘텐츠도 백업하므로 옛 저장소가 사라져도 복원 자료가 남는다. 파일 교체 도중 예외가 발생하면 이전 파일 복원을 시도하고, 복원이 실패하면 journal을 남겨 recover로 처리한다. 전원 차단·디스크 손상을 포함한 완전한 원자성은 보장하지 않는다.

`doctor`는 원본과 설치 패키지 차이, 직접 변경, 역할 모델, 로컬 키 이름 등을 표시한다. 프로젝트별 설정과 현재 세션의 선택, 계정 모델 권한까지 확정하는 도구는 아니다.

## 제외한 내용

기존 state 40개, 하드코딩된 Mac 프로젝트 경로·홈 trust 목록, UI 사용 기록, 시스템 스킬 복사본, 인증·세션·로그·캐시를 배포본에서 제외했다. 테스트 fixtures의 옛 역할·스킬은 마이그레이션 검증 자료이며 설치 대상이 아니다.

별도 하네스·관리 서버·Rooty 중계·위키 전체 복제·상시 자동 pull·자동 커밋·모델 자동 상향/하향은 추가하지 않았다. Rooty의 비공개 기억이나 Shared Wiki의 snapshot/outbox 정책도 바꾸지 않았다.

## 토큰 판단

소스 중복 제거와 짧은 위임 계약, 스킬의 명시적 호출을 사용한다. 다만 공통 안전 규칙을 보완했으므로 전역 AGENTS의 바이트 수가 이전 conf보다 조금 늘었다. 소스 파일 중복 제거가 실제 프롬프트 토큰 절감과 같다고 주장하지 않는다. 스킬 metadata도 문맥에 남는다. 실제 요청별 input/output/cache usage 및 비용은 계정 세션으로 별도 측정해야 한다.

## 확인하지 못한 범위

실제 사용자 Codex 버전과 모델 호출, 네이티브 Mac/Windows, 키체인·GUI 환경, Gitea 인증, 실사용 토큰 절감은 미검증이다. 공개 문서와 다른 `max`는 원본을 보존하되 CLI 검사에서 실패하면 중단한다. 기존 사용 환경에서 실제 동작했다는 사용자 설명은 존중하지만 새 기기 지원을 추정하지 않는다.
